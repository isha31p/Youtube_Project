# Databricks notebook source
# MAGIC %sql
# MAGIC create connection if not exists youtube_earthquake_conn
# MAGIC type HTTP
# MAGIC options(
# MAGIC     host='https://earthquake.usgs.gov',
# MAGIC     port= 443,
# MAGIC     base_path= '/earthquakes/feed/v1.0/',
# MAGIC     bearer_token = 'na'
# MAGIC )

# COMMAND ----------

from databricks.sdk import WorkspaceClient
w = WorkspaceClient()
conn = w.connections.get("youtube_earthquake_conn")

base_url = f"{conn.options['host']}{conn.options['base_path']}"



# COMMAND ----------

dbutils.widgets.text('catalog_name','youtube_dev','youtube_dev')
catalog_name=dbutils.widgets.get('catalog_name')


# COMMAND ----------

spark.sql(
    f"use catalog {catalog_name}"
)
spark.sql(
    "use schema bronze"
)
spark.sql(
    "create volume if not exists earthquake_data"

)


# COMMAND ----------

import requests
import json
import datetime
url='https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson'
response=requests.get(url)
if(response.status_code!=200):
  raise Exception(f'error in getting data from {url}')
data=response.json()
current_date=datetime.datetime.now().strftime("%Y-%m-%d")
dbutils.fs.put(f'/Volumes/{catalog_name}/bronze/earthquake_data/earthquake_data_{current_date}.json',json.dumps(data),overwrite=True)
